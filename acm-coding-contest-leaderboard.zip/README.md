# ACM Coding Contest Leaderboard Dashboard

A modern, professional, and fully responsive Coding Contest Leaderboard web application designed for an official **ACM Student Chapter**.

Built with **React.js, HTML5, CSS3, and modern JavaScript**, featuring pure custom SVG/CSS visualizations, deterministic tie-breaking logic adhering to official **ICPC / ACM contest scoring**, rich participant dossiers, and real-time interactive analytics.

---

## Key Features

1. **Overview Dashboard**:
   - High-level metric cards: Total Registered Participants, Total Contest Problems, Total Submissions, Accepted Count, Duration, Active Solvers.
   - **Participation Funnel**: Visual tracking of registered vs. active submission vs. problem solvers.
   - **Submission Verdict Breakdown**: Visual segmented proportion bar and numerical metrics for Accepted (AC), Wrong Answer (WA), Time Limit Exceeded (TLE), and Runtime Errors (RTE/CE).
   - **Performance Charts**: Score distribution buckets and problem-wise acceptance rates rendered with pure HTML/CSS/SVG (no heavy external chart libraries).
   - **Podium Layout**: Elegant top 3 contenders presentation with gold, silver, and bronze rank indicators.
   - **Live Contest Activity Stream**: Chronological evaluation log with a **"Simulate Live Verdict"** feature to test dynamic scoreboard recalculations in real time.

2. **Official Contest Leaderboard Table**:
   - Detailed columns: Rank (+ rank movement $\blacktriangle$, $\blacktriangledown$, —), Contestant Name, Username, Institution, Total Score, Problems Solved ($X/N$), Total Attempts, Accuracy %, Cumulative Penalty Minutes, and Last Accepted AC time.
   - **Task Matrix Strip**: Visual indicators for P1–P6 showing attempt count on solved tasks (`+1`, `+2`), failed tasks (`-3`), and untouched tasks.
   - **Tie-Breaker Hierarchy**: Implements official ICPC rules (Higher Score $\to$ Higher Solved Count $\to$ Lower Penalty Time $\to$ Earliest Last AC).
   - Current user indicator (`YOU` badge) and custom row highlighting.
   - Responsive table wrapper and smooth pagination.

3. **Search, Filter & Sorting System**:
   - Instant text search matching contestant name, handle (`@username`), or institution.
   - Multi-dropdown filters: Institution / College, Problems Solved threshold, Score Tier, and Rank Range.
   - Sorting options: Official Rank, Score (High $\to$ Low), Score (Low $\to$ High), Solved Count, Highest Accuracy, and Lowest Penalty.
   - One-click **"Reset Filters"** and **"Export CSV"** for contest coordinators.

4. **Interactive Participant Dossier (Modal)**:
   - Click any contestant to open their complete performance modal.
   - Key summary tiles (Rank, Score, Solved, Attempts, Accuracy, Penalty).
   - Problem-by-problem matrix with solve timestamps, rejected attempts, and penalty minutes earned.
   - Algorithmic coverage insights and complete submission history with runtime (ms) and memory footprint.
   - Ability to pin any participant as "You" to test row distinction.

5. **Problem Statistics Page**:
   - Problem code, title, difficulty (Easy, Medium, Hard), point weight, limits, attempts, accepted count, and solver count.
   - Difficulty filter (All, Easy, Medium, Hard).
   - Clickable task statement modal showing input/output format and list of students who solved each problem.

6. **Contest Details & Guidelines**:
   - Schedule, duration, penalty rules, evaluation environment (compilers, runtime flags), and honor code.

7. **About ACM Chapter**:
   - Chapter mission, executive committee directory, faculty sponsor, and competitive programming initiatives.

---

## Scoring & Tie-Breaking Logic

The scoring engine adheres strictly to the **ICPC Collegiate Programming Contest** standard (`src/utils/calculations.ts`):

1. **Problem Points**:
   - Each problem has a designated point value: Easy (100 pts), Medium (150 pts), Hard (200–250 pts).
   - A participant is awarded points only when producing an `AC` (Accepted) verdict on that problem.

2. **Penalty Time Calculation**:
   $$\text{Penalty} = \text{Time of AC (minutes from start)} + (\text{Number of Rejected Runs Prior to AC} \times 20)$$
   - Submissions on problems that were never solved contribute **$0$ penalty minutes**.

3. **Accuracy Percentage**:
   $$\text{Accuracy \%} = \left(\frac{\text{Accepted Submissions}}{\text{Total Attempts}}\right) \times 100$$

4. **Tie-Breaker Priority**:
   - **1st Priority**: Higher Total Score
   - **2nd Priority**: More Problems Solved
   - **3rd Priority**: Lower Cumulative Penalty Time
   - **4th Priority**: Earliest Last Accepted Submission Time
   - **5th Priority**: Alphabetical order of contestant name

---

## Project Structure

```text
├── index.html                   # Entry HTML with custom typography (Plus Jakarta Sans & JetBrains Mono)
├── package.json                 # Project dependencies and npm scripts
├── src/
│   ├── types/
│   │   └── contest.ts           # TypeScript interfaces for Contest, Problems, Participants, Submissions
│   ├── data/
│   │   ├── contest.ts           # Contest metadata, schedule, and rules
│   │   ├── problems.ts          # 6 competitive programming challenges (Easy, Medium, Hard)
│   │   ├── participants.ts      # 20 realistic collegiate participants
│   │   └── submissions.ts       # 60+ realistic submission evaluation records
│   ├── utils/
│   │   ├── calculations.ts      # ICPC scoring, penalty formulas, and stats aggregators
│   │   └── filters.ts           # Search, multi-filtering, sorting, and CSV export
│   ├── components/
│   │   ├── Navbar.tsx           # Top navigation bar with live status, search, and notifications
│   │   ├── Sidebar.tsx          # Collapsible desktop sidebar & mobile drawer menu
│   │   ├── StatCard.tsx         # Clean metric card
│   │   ├── Charts.tsx           # Pure HTML/CSS/SVG charts (Score distribution, Acceptance rates)
│   │   ├── TopPerformers.tsx    # Podium presentation for Ranks 1, 2, 3
│   │   ├── RecentActivity.tsx   # Live submission stream with simulation trigger
│   │   ├── Overview.tsx         # Executive contest overview dashboard
│   │   ├── LeaderboardTable.tsx # Standings table with problem matrix strip
│   │   ├── FilterPanel.tsx      # Search bar, dropdown filters, sort, reset, and CSV export
│   │   ├── Leaderboard.tsx      # Main leaderboard tab with pagination
│   │   ├── ParticipantDetails.tsx # Comprehensive participant profile modal
│   │   ├── ProblemStatisticsView.tsx # Problem analytics and problem statement viewer
│   │   ├── ContestDetailsView.tsx # Schedule, rules, and technical environment specifications
│   │   └── AboutACMView.tsx     # Student chapter overview and executive board directory
│   ├── App.tsx                  # Root application state and navigation wiring
│   ├── main.tsx                 # Application entry point
│   └── index.css                # Global CSS variables, modern scrollbars, and styling
```

---

## Local Installation & Execution

To run this application locally:

1. Clone or download the repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the local development server:
   ```bash
   npm run dev
   ```
4. Open your browser and navigate to `http://localhost:3000`.
5. To test production compilation:
   ```bash
   npm run build
   ```
